module Db
  module Core
    def binary_search

    end
  end
end