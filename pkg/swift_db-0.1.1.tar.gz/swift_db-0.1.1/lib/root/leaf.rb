module Db
  module Core
    class Leaf
      def initialize()

      end
    end
  end
end
